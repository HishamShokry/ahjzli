import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

let initialState = {
  isLoading: false,
  data: {},
  errors: [],
}

export const getPriceList = createAsyncThunk(
  "priceList/getPriceList",
  async (args, thunkApi) => {
    try {
      const { page, size = 10, query, filter = JSON.stringify({}) } = args;
      const { data } = await axios.get(
        `/api/get_price_list?page=${page}&size=${size}&query=${query}&filter=${filter}`,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    } catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const createPriceList = createAsyncThunk(
  "priceList/createPriceList",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.post(
        '/api/create_price_list',
        args,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const updatePriceList = createAsyncThunk(
  "priceList/updatePriceList",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.put(
        `/api/update_price_list/${args.id}`,
        args.values,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const deletePriceList = createAsyncThunk(
  "priceList/deletePriceList",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.delete(
        `/api/delete_price_list/${args._id}`,
        {
          headers: {
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
)

const priceListSlice = createSlice({
  name: "priceList",
  initialState,
  extraReducers: {
    [getPriceList.pending]: (state) => {
      state.isLoading = true;
      state.errors = [];
    },
    [getPriceList.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data = action.payload;
      state.errors = [];
    },
    [getPriceList.rejected]: (state, action) => {
      state.isLoading = false;
      state.data = {};
      state.errors = action.payload.errors;
    },

    // create shipping company
    [createPriceList.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [createPriceList.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data.itemsCount++;
      state.data?.data?.length < 10 && state.data.data.push(action.payload.data);
      state.errors = [];
    },
    [createPriceList.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    },

    // update shipping company
    [updatePriceList.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [updatePriceList.fulfilled]: (state, action) => {
      state.isLoading = false;
      const indexAt = state.data.data?.findIndex(el => el._id === action.payload.data._id);
      state.data.data[indexAt] = action.payload.data;
      state.errors = [];
    },
    [updatePriceList.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    },

    // delete shipping company
    [deletePriceList.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [deletePriceList.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data.data = state.data.data.filter(el => el._id !== action.payload.data._id);
      state.errors = [];
    },
    [deletePriceList.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    }
  }
});

export default priceListSlice.reducer;