import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

let initialState = {
  isLoading: false,
  data: {},
  errors: [],
}

export const getWarehouses = createAsyncThunk(
  "warehouses/getWarehouses",
  async (args, thunkApi) => {
    try {
      const { page, size = 10, query, filter = JSON.stringify({}) } = args;
      const { data } = await axios.get(
        `/api/get_warehouses?page=${page}&size=${size}&query=${query}&filter=${filter}`,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    } catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const createWarehouse = createAsyncThunk(
  "warehouses/createWarehouse",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.post(
        '/api/create_warehouse',
        args,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const updateWarehouse = createAsyncThunk(
  "warehouses/updateWarehouse",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.put(
        `/api/update_warehouse/${args.id}`,
        args.values,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const deleteWarehouse = createAsyncThunk(
  "warehouses/deleteWarehouse",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.delete(
        `/api/delete_warehouse/${args._id}`,
        {
          headers: {
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
)

const warehousesSlice = createSlice({
  name: "warehouses",
  initialState,
  extraReducers: {
    [getWarehouses.pending]: (state) => {
      state.isLoading = true;
      state.errors = [];
    },
    [getWarehouses.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data = action.payload;
      state.errors = [];
    },
    [getWarehouses.rejected]: (state, action) => {
      state.isLoading = false;
      state.data = {};
      state.errors = action.payload.errors;
    },

    // create warehouse
    [createWarehouse.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [createWarehouse.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data.itemsCount++;
      state.data?.data?.length < 10 && state.data.data.push(action.payload.data);
      state.errors = [];
    },
    [createWarehouse.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    },

    // update warehouse
    [updateWarehouse.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [updateWarehouse.fulfilled]: (state, action) => {
      state.isLoading = false;
      const indexAt = state.data.data?.findIndex(el => el._id === action.payload.data._id);
      state.data.data[indexAt] = action.payload.data;
      state.errors = [];
    },
    [updateWarehouse.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    },

    // delete warehouse
    [deleteWarehouse.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [deleteWarehouse.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data.data = state.data.data.filter(el => el._id !== action.payload.data._id);
      state.errors = [];
    },
    [deleteWarehouse.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    }
  }
});

export default warehousesSlice.reducer;