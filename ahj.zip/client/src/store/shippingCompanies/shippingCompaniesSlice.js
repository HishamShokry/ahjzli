import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

let initialState = {
  isLoading: false,
  data: {},
  errors: [],
}

export const getShippingCompanies = createAsyncThunk(
  "shippingCompanies/getShippingCompanies",
  async (args, thunkApi) => {
    try {
      const { page, size = 10, query, filter = JSON.stringify({}) } = args;
      const { data } = await axios.get(
        `/api/get_shipping_companies?page=${page}&size=${size}&query=${query}&filter=${filter}`,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    } catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const createShippingCompany = createAsyncThunk(
  "shippingCompanies/createShippingCompany",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.post(
        '/api/create_shipping_company',
        args,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const updateShippingCompany = createAsyncThunk(
  "shippingCompanies/updateShippingCompany",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.put(
        `/api/update_shipping_company/${args.id}`,
        args.values,
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
);

export const deleteShippingCompany = createAsyncThunk(
  "shippingCompanies/deleteShippingCompany",
  async (args, thunkApi) => {
    try {
      const { data } = await axios.delete(
        `/api/delete_shipping_company/${args._id}`,
        {
          headers: {
            'Authorization': thunkApi.getState().auth.token
          }
        }
      );
      return thunkApi.fulfillWithValue(data);
    }
    catch (errors) {
      return thunkApi.rejectWithValue(
        errors.response.status !== 400
          ?
          { errors: [{ 'msg': 'something went wrong' }] }
          :
          errors.response.data
      );
    }
  }
)

const shippingCompaniesSlice = createSlice({
  name: "shippingCompanies",
  initialState,
  extraReducers: {
    [getShippingCompanies.pending]: (state) => {
      state.isLoading = true;
      state.errors = [];
    },
    [getShippingCompanies.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data = action.payload;
      state.errors = [];
    },
    [getShippingCompanies.rejected]: (state, action) => {
      state.isLoading = false;
      state.data = {};
      state.errors = action.payload.errors;
    },

    // create shipping company
    [createShippingCompany.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [createShippingCompany.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data.itemsCount++;
      state.data?.data?.length < 10 && state.data.data.push(action.payload.data);
      state.errors = [];
    },
    [createShippingCompany.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    },

    // update shipping company
    [updateShippingCompany.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [updateShippingCompany.fulfilled]: (state, action) => {
      state.isLoading = false;
      const indexAt = state.data.data?.findIndex(el => el._id === action.payload.data._id);
      state.data.data[indexAt] = action.payload.data;
      state.errors = [];
    },
    [updateShippingCompany.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    },

    // delete shipping company
    [deleteShippingCompany.pending]: state => {
      state.isLoading = true;
      state.errors = [];
    },
    [deleteShippingCompany.fulfilled]: (state, action) => {
      state.isLoading = false;
      state.data.data = state.data.data.filter(el => el._id !== action.payload.data._id);
      state.errors = [];
    },
    [deleteShippingCompany.rejected]: (state, action) => {
      state.isLoading = false;
      state.errors = action.payload.errors;
    }
  }
});

export default shippingCompaniesSlice.reducer;