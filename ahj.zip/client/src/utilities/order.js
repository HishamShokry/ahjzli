const convertArNumbersToEnNumbers = (value) => {
  var yas = value;
  yas = yas.replace(/[٠١٢٣٤٥٦٧٨٩]/g, function (d) { return d.charCodeAt(0) - 1632; })
    .replace(/[۰۱۲۳۴۵۶۷۸۹]/g, function (d) { return d.charCodeAt(0) - 1776; });
  return yas
}

export { convertArNumbersToEnNumbers }