import styled from 'styled-components';

export const WarehousesWrapper = styled.div`
`;