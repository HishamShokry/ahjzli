import styled from 'styled-components';

export const SupportsWrapper = styled.div`
  
`;