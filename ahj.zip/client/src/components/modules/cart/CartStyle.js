import styled from "styled-components";

export const CartWrapper = styled.div`
`;