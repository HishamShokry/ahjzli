import styled from 'styled-components';

export const CategoriesWrapper = styled.div`

`;