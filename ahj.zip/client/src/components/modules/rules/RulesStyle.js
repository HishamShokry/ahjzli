import styled from 'styled-components';

export const RulesWrapper = styled.div`
  
`;