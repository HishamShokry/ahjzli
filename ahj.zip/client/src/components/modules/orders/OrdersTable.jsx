import React from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import { Box, Button } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';

import Table from '../../shared/table/Table';

import { cities, governorates } from '../../../utilities/places';

import theme from '../../global/theme';

const OrdersTable = ({
  data,
  handleUpdate,
  handleOrderStatus,
  handleSelectOrder,
  handleSelectAllOrders
}) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const auth = useSelector(state => state.auth);

  const systemRevenue = (items) => {
    let total = 0;
    for (let i = 0; i < items.length; i++) {
      const totalPurchasePrice = items[i].total_purchase_price;
      const totalSalePrice = items[i].total_sale_price;
      total += totalSalePrice - totalPurchasePrice;
    }
    return total;
  }

  const marketer = (
    <Table id="table-to-xls">
      <thead>
        <tr>
          <th>#</th>
          <th>{t('pages.orders.serial_number')}</th>
          <th>مودريتور</th>
          <th>{t('pages.orders.client_name')}</th>
          <th>{t('pages.orders.client_phone1')}</th>
          <th>{t('pages.orders.products')}</th>
          <th>{t('pages.orders.total')}</th>
          <th>{t('pages.orders.commission')}</th>
          <th>تاريخ الانشاء</th>
          <th>{t('pages.orders.last_update')}</th>
          <th>{t('pages.orders.governorate')}</th>
          <th>{t('pages.orders.note')}</th>
          <th>{t('pages.orders.holding_to')}</th>
          <th>{t('pages.orders.status')}</th>
          <th>{t('general.action')}</th>
        </tr>
      </thead>
      <tbody>
        {data.map((el, index) => (
          <tr key={el._id}>
            <td>{index + 1}</td>
            <td>{el.serial_number}</td>
            <td>{el.moderator?.name || '-'}</td>
            <td>{el.client_name}</td>
            <td>{el.client_phone1}</td>
            <td>
              {el.items?.length && el.items.map((item, idx) => `(${item.qty}) قطعة ${item.product?.name} - ${item.product.properties.find(it => it._id === item.property)?.key} ${el.items?.length === (idx + 1) ? "" : "//"} `)}
            </td>
            <td>{el.total}</td>
            <td>{el.commission}</td>
            <td>{new Date(el.created_at).toLocaleDateString()}</td>
            <td>{new Date(el.updated_at).toLocaleDateString()}</td>
            <td>{governorates.find(gov => +gov.id === el.shipping_governorate?.governorate)?.governorate_name_ar}</td>
            <td>{el.note}</td>
            <td>{el.holding_to ? new Date(el.holding_to).toLocaleString() : '-'}</td>
            <td>
              <Box
                as="span" borderRadius="5px" fontSize="12px" whiteSpace="nowrap"
                paddingBlock={1} paddingInline={2}
                color={theme.light}
                background={
                  el.status === "pending" ?
                    "yellow.400"
                    : el.status === "preparing"
                      ?
                      "orange"
                      : el.status === "shipped"
                        ?
                        "#0094B7"
                        : el.status === "available"
                          ?
                          "green"
                          :
                          "red"
                }
              >
                {t(`pages.orders.${el.status}`)}
              </Box>
            </td>
            <td>
              <Box>
                <Button bg={theme.error} fontSize="10px"
                  size="xs" color={theme.light} mb={4}
                  onClick={() => navigate(`/orders/order_details/${el._id}`)}
                >
                  تفاصيل الطلب
                </Button>

                <Button flex="1"
                  bg={theme.blue} color={theme.light} size="xs" mb={2}
                  onClick={() => navigate(`/orders/${el._id}/notes`)}
                >
                  <Box position="relative">
                    <span>ملاحظات الطلب</span>
                    {el.replies.length > 0 && (
                      <Box
                        position="absolute" top="-15px" left="-1px" w="15px" h="15px"
                        bg={theme.error} color={theme.light} borderRadius="50%" fontSize="6px"
                        d="flex" alignItems="center" justifyContent="center"
                      >
                        {el.replies?.length ?? 0}
                      </Box>
                    )}
                  </Box>
                </Button>
              </Box>

              {el.status !== "pending" && (
                <Button
                  type="button" size="xs"
                  onClick={() => handleOrderStatus(el)}
                >
                  تتبع الطلب
                </Button>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );

  const moderator = (
    <Table id="table-to-xls">
      <thead>
        <tr>
          <th>#</th>
          <th>{t('pages.orders.serial_number')}</th>
          <th>{t('pages.orders.client_name')}</th>
          <th>{t('pages.orders.client_phone1')}</th>
          <th>{t('pages.orders.governorate')}</th>
          <th>{t('pages.orders.products')}</th>
          <th>{t('pages.orders.total')}</th>
          <th>تاريخ الانشاء</th>
          <th>{t('pages.orders.last_update')}</th>
          <th>{t('pages.orders.note')}</th>
          <th>{t('pages.orders.holding_to')}</th>
          <th>{t('pages.orders.status')}</th>
          <th>{t('general.action')}</th>
        </tr>
      </thead>
      <tbody>
        {data.map((el, index) => (
          <tr key={el._id}>
            <td>{index + 1}</td>
            <td>{el.serial_number}</td>
            <td>{el.client_name}</td>
            <td>{el.client_phone1}</td>
            <td>{governorates.find(gov => +gov.id === el.shipping_governorate?.governorate)?.governorate_name_ar}</td>
            <td>
              {el.items?.length && el.items.map((item, idx) => `(${item.qty}) قطعة ${item.product?.name} - ${item.product.properties.find(it => it._id === item.property)?.key} ${el.items?.length === (idx + 1) ? "" : "//"} `)}
            </td>
            <td>{el.total}</td>
            <td>{new Date(el.created_at).toLocaleDateString()}</td>
            <td>{new Date(el.updated_at).toLocaleDateString()}</td>
            <td>{el.note}</td>
            <td>{el.holding_to ? new Date(el.holding_to).toLocaleString() : '-'}</td>
            <td>
              <Box
                as="span" borderRadius="5px" fontSize="12px" whiteSpace="nowrap"
                paddingBlock={1} paddingInline={2}
                color={theme.light}
                background={
                  el.status === "pending" ?
                    "yellow.400"
                    : el.status === "preparing"
                      ?
                      "orange"
                      : el.status === "shipped"
                        ?
                        "#0094B7"
                        : el.status === "available"
                          ?
                          "green"
                          :
                          "red"
                }
              >
                {t(`pages.orders.${el.status}`)}
              </Box>
            </td>
            <td>
              <Box>
                <Button bg={theme.error} fontSize="10px"
                  size="xs" color={theme.light} mb={4}
                  onClick={() => navigate(`/orders/order_details/${el._id}`)}
                >
                  تفاصيل الطلب
                </Button>

                <Button flex="1"
                  bg={theme.blue} color={theme.light} size="xs" mb={2}
                  onClick={() => navigate(`/orders/${el._id}/notes`)}
                >
                  <Box position="relative">
                    <span>ملاحظات الطلب</span>
                    {el.replies.length > 0 && (
                      <Box
                        position="absolute" top="-15px" left="-1px" w="15px" h="15px"
                        bg={theme.error} color={theme.light} borderRadius="50%" fontSize="6px"
                        d="flex" alignItems="center" justifyContent="center"
                      >
                        {el.replies?.length ?? 0}
                      </Box>
                    )}
                  </Box>
                </Button>

                {(auth.user.role === "admin" && el.status === "pending") && (
                  <Button flex="1"
                    bg="transparent" color="green" size="xs" mb={2}
                    onClick={() => handleUpdate(el)}
                  >
                    <FiIcons.FiEdit size={20} />
                  </Button>
                )}

              </Box>

              {el.status !== "pending" && (
                <Button
                  type="button" size="xs"
                  onClick={() => handleOrderStatus(el)}
                >
                  تتبع الطلب
                </Button>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );

  const admin = (
    <Table id="table-to-xls">
      <thead>
        <tr>
          <th>#</th>
          <th>الربح</th>
          <th>مودريتور</th>
          <th>{t('pages.orders.serial_number')}</th>
          <th>{t('pages.orders.client_name')}</th>
          <th>{t('pages.orders.client_phone1')}</th>
          <th>{t('pages.orders.client_phone2')}</th>
          <th>{t('pages.orders.governorate')}</th>
          <th>{t('pages.orders.city')}</th>
          <th>{t('pages.orders.client_address')}</th>
          <th>{t('pages.orders.products')}</th>
          <th>{t('pages.orders.total')}</th>
          <th>{t('pages.orders.commission')}</th>
          <th>تاريخ الانشاء</th>
          <th>{t('pages.orders.last_update')}</th>
          <th>{t('pages.orders.note')}</th>
          <th>{t('pages.orders.holding_to')}</th>
          <th>شركة الشحن</th>
          <th>{t('pages.orders.status')}</th>
          <th className="removable">{t('general.action')}</th>
          <th className="removable">
            <Button type="button" onClick={handleSelectAllOrders}>تحديد الكل</Button>
          </th>
        </tr>
      </thead>
      <tbody>
        {data.map((el, index) => (
          <tr key={el._id}>
            <td>{index + 1}</td>
            <td>{systemRevenue(el.items)}</td>
            <td>{el.moderator?.name || '-'}</td>
            <td>{el.serial_number}</td>
            <td>{el.client_name}</td>
            <td>{el.client_phone1}</td>
            <td>{el.client_phone2 || '-'}</td>
            <td>{governorates.find(gov => +gov.id === el.shipping_governorate?.governorate)?.governorate_name_ar}</td>
            <td>{cities.find(city => +city.id === el.city)?.city_name_ar}</td>
            <td>{el.client_address}</td>
            <td>
              {el.items?.length && el.items.map((item, idx) => `(${item.qty}) قطعة ${item.product?.name} - ${item.product.properties.find(it => it._id === item.property)?.key} ${el.items?.length === (idx + 1) ? "" : "//"} `)}
            </td>
            <td>{el.total}</td>
            <td>{el.commission}</td>
            <td>{new Date(el.created_at).toLocaleDateString()}</td>
            <td>{new Date(el.updated_at).toLocaleDateString()}</td>
            <td>{el.note}</td>
            <td>{el.holding_to ? new Date(el.holding_to).toLocaleString() : '-'}</td>
            <td>{el.shipping_company?.name ?? "-"}</td>
            <td>
              <Box
                as="span" borderRadius="5px" fontSize="12px" whiteSpace="nowrap"
                paddingBlock={1} paddingInline={2}
                color={theme.light}
                background={
                  el.status === "pending" ?
                    "yellow.400"
                    : el.status === "preparing"
                      ?
                      "orange"
                      : el.status === "shipped"
                        ?
                        "#0094B7"
                        : el.status === "available"
                          ?
                          "green"
                          :
                          "red"
                }
              >
                {t(`pages.orders.${el.status}`)}
              </Box>
            </td>
            <td className="removable">
              <Box>
                <Button bg={theme.error} fontSize="10px"
                  size="xs" color={theme.light} mb={4}
                  onClick={() => navigate(`/orders/order_details/${el._id}`)}
                >
                  تفاصيل الطلب
                </Button>

                <Button flex="1"
                  bg={theme.blue} color={theme.light} size="xs" mb={2}
                  onClick={() => navigate(`/orders/${el._id}/notes`)}
                >
                  <Box position="relative">
                    <span>ملاحظات الطلب</span>
                    {el.replies.length > 0 && (
                      <Box
                        position="absolute" top="-15px" left="-1px" w="15px" h="15px"
                        bg={theme.error} color={theme.light} borderRadius="50%" fontSize="6px"
                        d="flex" alignItems="center" justifyContent="center"
                      >
                        {el.replies?.length ?? 0}
                      </Box>
                    )}
                  </Box>
                </Button>

                {(auth.user.role === "admin" && el.status === "pending") && (
                  <Button flex="1"
                    bg="transparent" color="green" size="xs" mb={2}
                    onClick={() => handleUpdate(el)}
                  >
                    <FiIcons.FiEdit size={20} />
                  </Button>
                )}

              </Box>

              {el.status !== "pending" && (
                <Button
                  type="button" size="xs"
                  onClick={() => handleOrderStatus(el)}
                >
                  تتبع الطلب
                </Button>
              )}
            </td>
            <td className="removable">
              <input
                type="checkbox"
                style={{ width: "25px", height: "25px" }}
                className="order-check"
                onChange={(e) => handleSelectOrder(el, e)}
              />
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );

  const merchant = (
    <Table id="table-to-xls">
      <thead>
        <tr>
          <th>#</th>
          <th>{t('pages.orders.serial_number')}</th>
          <th>{t('pages.orders.products')}</th>
          <th>تاريخ الانشاء</th>
          <th>{t('pages.orders.last_update')}</th>
          <th>{t('pages.orders.governorate')}</th>
          <th>{t('pages.orders.holding_to')}</th>
          <th>{t('pages.orders.status')}</th>
        </tr>
      </thead>
      <tbody>
        {data.map((el, index) => (
          <tr key={el._id}>
            <td>{index + 1}</td>
            <td>{el.serial_number}</td>
            <td>
              {el.items?.length && el.items.map((item, idx) => item.merchant === auth.user._id && `(${item.qty}) قطعة ${item.product?.name} - ${item.product.properties.find(it => it._id === item.property)?.key} ${el.items?.length === (idx + 1) ? "" : "//"} `)}
            </td>
            <td>{new Date(el.created_at).toLocaleDateString()}</td>
            <td>{new Date(el.updated_at).toLocaleDateString()}</td>
            <td>{governorates.find(gov => +gov.id === el.shipping_governorate?.governorate)?.governorate_name_ar}</td>
            <td>{el.holding_to ? new Date(el.holding_to).toLocaleString() : '-'}</td>
            <td>
              <Box
                as="span" borderRadius="5px" fontSize="12px" whiteSpace="nowrap"
                paddingBlock={1} paddingInline={2}
                color={theme.light}
                background={
                  el.status === "pending" ?
                    "yellow.400"
                    : el.status === "preparing"
                      ?
                      "orange"
                      : el.status === "shipped"
                        ?
                        "#0094B7"
                        : el.status === "available"
                          ?
                          "green"
                          :
                          "red"
                }
              >
                {t(`pages.orders.${el.status}`)}
              </Box>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );

  const authQ = {
    marketer,
    moderator,
    admin,
    merchant
  };

  return authQ[auth.user.role];
}

export default OrdersTable