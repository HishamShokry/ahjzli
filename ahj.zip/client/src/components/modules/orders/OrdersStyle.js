import styled from 'styled-components';

export const OrdersWrapper = styled.div``;