import React, { useState, useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import TableToExcel from 'table-to-excel';

import { Flex, Button, Text, SimpleGrid, Alert, AlertIcon, Select, Box } from '@chakra-ui/react';

import * as FiIcons from 'react-icons/fi';

import Pagination from '../../shared/pagination/Pagination';
import Breadcrumbs from '../../shared/breadcrumbs/Breadcrumbs';
import OrdersTable from './OrdersTable';
import CreateModal from './actions/CreateModal';
import UpdateModal from './actions/UpdateModal';
import UpdateShippingCompanyModal from './actions/UpdateShippingCompanyModal';
import OrderStatusModal from './actions/OrderStatusModal';
import UpdateOrdersStatusModal from './actions/UpdateOrdersStatusModal';
import Filter from './actions/Filter';

import { getOrders } from '../../../store/orders/ordersSlice';

import { OrdersWrapper } from './OrdersStyle';

import theme from '../../global/theme';
import InputSearch from '../../shared/inputSearch/InputSearch';

const tableToExcel = new TableToExcel();

const Orders = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const orders = useSelector(state => state.orders);

  const [searchParams, setSearchParams] = useSearchParams();
  const createOrderBtnRef = useRef();

  const page = +searchParams.get("page") || 1;
  const size = +searchParams.get("size") || 20;
  const query = searchParams.get("query") || "";

  const defaultFilter = {};
  const status = searchParams.get("status");
  if (status) {
    defaultFilter["status"] = status;
  }

  const [filter, setFilter] = useState(JSON.stringify(defaultFilter));

  const [showCreateOrder, setShowCreateOrder] = useState(false);
  const [showUpdateOrder, setShowUpdateOrder] = useState(false);
  const [showUpdateOrdersShippingCompany, setShowUpdateOrdersShippingCompany] = useState(false);
  const [showOrderStatus, setShowOrderStatus] = useState(false);

  const [updateOrders, setUpdateOrders] = useState([]);
  const [showUpdateOrdersStatus, setShowUpdateOrdersStatus] = useState(false);

  useEffect(() => {
    if (searchParams.get("open_modal") && searchParams.get("open_modal") === "true") {
      createOrderBtnRef.current.click();
      searchParams.delete("open_modal");
      setSearchParams(searchParams);
    }
  }, [searchParams, setSearchParams]);


  useEffect(() => {
    dispatch(getOrders({ page, query, size, filter }));
  }, [dispatch, page, query, size, filter]);


  return (
    <OrdersWrapper>
      <Breadcrumbs currentPage={t('pages.orders.orders')} pages={[{ name: `${t('pages.dashboard.dashboard')}`, path: '/' }]} />

      {orders.errors.length > 0 && <Alert status="error" variant="left-accent" marginBottom={8}>
        <AlertIcon />
        {orders.errors?.map((error, index) => (
          <Text key={index}>{error?.msg}</Text>
        ))}
      </Alert>}

      <SimpleGrid columns={{ sm: 1, lg: 2, xl: 4 }} spacing={4} mb={8}>
        <Flex
          boxShadow={theme.shadow} bg={!status ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#1C3FAA">
              <FiIcons.FiShoppingCart size={40} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.allOrders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              اجمالي الطلبات
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "pending" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=pending&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#1C3FAA">
              <FiIcons.FiShoppingCart size={40} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.pendingOrders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات معلقة
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "preparing" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=preparing&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#F78B00">
              <FiIcons.FiShoppingCart size={40} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.preparingOrders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات جار التحضير
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "shipped" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=shipped&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#F44336">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.shippedOrders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات تم الشحن
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "available" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=available&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#092871">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.availableOrders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات تم التوصيل
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "skip" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=skip&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#092871">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.skipOrders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              جار الاسترجاع
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "holding" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=holding&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#22c437">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.holdingOrders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات مؤجله
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "ask_to_return" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=ask_to_return&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#fbeb06">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.asToReturnOrders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلب استرجاع من العميل
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "returned1" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=returned1&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#3d3b1f">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.returned1Orders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات مرتجعة
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "returned2" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=returned2&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#3d3b1f">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.returned2Orders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات مرتجعة بعد التسليم
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "declined1" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=declined1&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#3d3b1f">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.declined1Orders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات ملغية
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>

        <Flex
          boxShadow={theme.shadow} bg={status === "declined2" ? "#539884" : theme.light} padding={6} alignItems="center" justifyContent="space-between"
          as="a" href={`/orders?status=declined2&page=${page}&size=${size}&query=${query}`}
        >
          <Flex justifyContent="space-between">
            <Box color="#3d3b1f">
              <FiIcons.FiShoppingCart size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
            >
              {orders.data?.declined2Orders}
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
              طلبات ملغية اثناء التحضير
            </Text>
            <Text
              fontWeight="bold" fontSize={12} textTransform="capitalize" color={theme.dark} mt={3}>
              انقر للفلترة
            </Text>
          </Box>
        </Flex>
      </SimpleGrid>

      <SimpleGrid columns={{ sm: 1, md: 2 }} justifyContent="space-between">
        <Flex mb={8}>
          <Button bg="red.600" textTransform="uppercase"
            fontWeight="bold" fontSize={18} marginInlineEnd={4} color="white" _hover={{ bg: 'red.600' }}
            onClick={() => setShowCreateOrder(true)} ref={createOrderBtnRef}
          >
            انشاء طلب +
          </Button>

          <Button type="button" variant="outline" onClick={() => {
            document.querySelectorAll('.removable').forEach(el => {
              el.remove();
            });
            tableToExcel.render("table-to-xls");
          }}>
            استخراج شيت اكسل
          </Button>
        </Flex>

        <Flex marginBottom={8} alignItems="center" justifyContent="flex-end">
          <InputSearch
            isLoading={orders.isLoading}
            handleSearch={(query) => {
              searchParams.set("query", query);
              setSearchParams(searchParams);
            }}
          />
        </Flex>
      </SimpleGrid>

      <Filter
        handleFilter={(values) => setFilter(JSON.stringify({ ...values, ...defaultFilter }))}
        handleClearFilter={() => setFilter(JSON.stringify(defaultFilter))}
        disablesBtns={orders.isLoading}
      />

      {
        updateOrders.length > 0 && (
          <Flex justifyContent="flex-end">
            <Button bg="red.600" mb={6} textTransform="uppercase"
              fontWeight="bold" fontSize={18} color="white" _hover={{ bg: 'green.600' }}
              onClick={() => setShowUpdateOrdersStatus(true)}
            >
              تحديث حالة الطلبات
            </Button>

            <Button bg="blue.600" mb={6} textTransform="uppercase" ms={4}
              fontWeight="bold" fontSize={18} color="white" _hover={{ bg: 'blue.600' }}
              onClick={() => setShowUpdateOrdersShippingCompany(true)}
            >
              شركة الشحن
            </Button>
          </Flex>
        )
      }

      {
        orders.data?.itemsCount > 0 ? (
          <OrdersTable
            data={orders.data.data}
            page={page}
            handleUpdate={(el) => setShowUpdateOrder(el)}
            handleOrderStatus={(el) => setShowOrderStatus(el)}
            handleSelectOrder={(el, e) => {
              if (e.target.checked) {
                setUpdateOrders([...updateOrders, el]);
              } else {
                const myOrders = updateOrders;
                const orders = myOrders.filter(o => o._id !== el._id);
                setUpdateOrders(orders);
              }
            }}
            handleSelectAllOrders={() => {
              const allChecks = document.querySelectorAll(".order-check");
              allChecks.forEach(el => {
                el.checked = true;
              });

              const allOrders = orders.data?.data ?? [];
              setUpdateOrders(allOrders);
            }}
          />
        ) : (
          <Flex textAlign="center" bg={theme.light} boxShadow={theme.shadow} height={200} alignItems="center"
            justifyContent="center" borderRadius={16}>
            <Text fontSize={18} textTransform="capitalize" color="gray.300" fontWeight="bold">
              {t('pages.orders.no_orders')}
            </Text>
          </Flex>
        )
      }

      <Flex justifyContent="space-between" alignItems="center">
        <Pagination
          page={+page}
          size={+size}
          itemsCount={orders.data?.itemsCount ?? 0}
          onChange={(page) => {
            searchParams.set("page", page);
            setSearchParams(searchParams);
          }}
        />
        <Select w="auto" mt="1.5rem" defaultValue={size} onChange={(e) => {
          searchParams.set("size", e.target.value);
          setSearchParams(searchParams);
        }}>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
          <option value="200">200</option>
          <option value="500">500</option>
          <option value="1000">1000</option>
          <option value="2000">2000</option>
        </Select>
      </Flex>

      {showCreateOrder && <CreateModal onClose={() => setShowCreateOrder(false)} />}
      {showUpdateOrder && <UpdateModal data={showUpdateOrder} onClose={() => setShowUpdateOrder(false)} />}
      {showUpdateOrdersShippingCompany && <UpdateShippingCompanyModal data={updateOrders} onClose={() => setShowUpdateOrdersShippingCompany(false)} />}
      {showOrderStatus && <OrderStatusModal data={showOrderStatus} onClose={() => setShowOrderStatus(false)} />}
      {showUpdateOrdersStatus && <UpdateOrdersStatusModal data={updateOrders} onClose={() => setShowUpdateOrdersStatus(false)} />}
    </OrdersWrapper >
  )
}

export default Orders