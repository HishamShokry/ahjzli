import { Box, Stack, Button } from '@chakra-ui/react';
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

import { updateNotification } from "../../../store/notifications/notificationsSlice";

import theme from '../../global/theme';

const NotificationsList = ({ data }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  return (
    <>
      <Stack bg={theme.dark} spacing={6} p={4} borderRadius={4}>
        {data.map(el => (
          el.type === "order_note" ? (
            <Button
              key={el._id} opacity={el.is_read ? .8 : 1}
              type="button" display="flex"
              onClick={() => {
                if (!el.is_read) {
                  dispatch(updateNotification({
                    _id: el._id,
                    is_read: true
                  })).unwrap().then(_ => {
                    navigate(`/orders/${el.order?._id}/notes`, {
                      state: el.order
                    })
                  })
                } else {
                  navigate(`/orders/${el.order?._id}/notes`, {
                    state: el.order
                  });
                }
              }}
            >
              <Box color={!el.is_read && theme.error} borderRadius={4} p={3} flex={1}>
                <Box d="inline-block" me={3}>لديك رساله في ملاحظات الطلب رقم</Box>
                <b>{el.order?.serial_number}</b>
              </Box>
            </Button>
          ) : el.type === "order_status" ? (
            <Button
              key={el._id} opacity={el.is_read ? .8 : 1}
              type="button" display="flex"
              onClick={() => {
                if (!el.is_read) {
                  dispatch(updateNotification({
                    _id: el._id,
                    is_read: true
                  })).unwrap().then(_ => {
                    navigate(`/orders/order_details/${el.order?._id}`)
                  })
                } else {
                  navigate(`/orders/order_details/${el.order?._id}`);
                }
              }}
            >
              <Box color={!el.is_read && theme.error} borderRadius={4} p={3} flex={1}>
                {/* <Box d="inline-block" me={3}>تم تغير حالة طلبك رقم</Box> */}
                {/* <b>{el.order?.serial_number}</b> */}
                <Box d="inline-block" me={3}>{el.content}</Box>
              </Box>
            </Button>
          ) : el.type === "request" ? (
            <Button
              key={el._id} opacity={el.is_read ? .8 : 1}
              type="button" display="flex"
              onClick={() => {
                if (!el.is_read) {
                  dispatch(updateNotification({
                    _id: el._id,
                    is_read: true
                  })).unwrap().then(_ => {
                    navigate("/requests")
                  })
                } else {
                  navigate("/requests");
                }
              }}
            >
              <Box color={!el.is_read && theme.error} borderRadius={4} p={3} flex={1}>
                <Box>{el.content}</Box>
              </Box>
            </Button>
          ) : el.type === "ticket" ? (
            <Button
              key={el._id} opacity={el.is_read ? .8 : 1}
              type="button" display="flex"
              onClick={() => {
                if (!el.is_read) {
                  dispatch(updateNotification({
                    _id: el._id,
                    is_read: true
                  })).unwrap().then(_ => {
                    navigate("/tickets")
                  })
                } else {
                  navigate("/tickets");
                }
              }}
            >
              <Box color={!el.is_read && theme.error} borderRadius={4} p={3} flex={1}>
                <Box>{el.content}</Box>
              </Box>
            </Button>
          ) : <span>-</span>
        ))}
      </Stack>
    </>
  )
}

export default NotificationsList