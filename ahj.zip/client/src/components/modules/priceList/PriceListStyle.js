import styled from 'styled-components';

export const PriceListWrapper = styled.section``;