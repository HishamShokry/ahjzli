import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import * as FiIcons from "react-icons/fi";
import { Flex, Text, Alert, AlertIcon, Box, SimpleGrid } from '@chakra-ui/react';

import Pagination from '../../shared/pagination/Pagination';
import Breadcrumbs from '../../shared/breadcrumbs/Breadcrumbs';
import MarktersAccountsTable from './MarketersAccountsTable';
import Filter from './actions/Filter';

import { getAccounts } from '../../../store/accounts/accountsSlice';

import { MarktersAccountsWrapper } from './MarketersAccountsStyle';

import theme from '../../global/theme';

const MarktersAccounts = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const accounts = useSelector(state => state.accounts);

  const [page, setPage] = useState(1);
  const defaultFilter = { role: 'marketer' };
  const [filter, setFilter] = useState(JSON.stringify(defaultFilter));

  useEffect(() => {
    dispatch(getAccounts({ page, query: "", filter }));
  }, [dispatch, page, filter]);


  return (
    <MarktersAccountsWrapper>
      <Breadcrumbs currentPage={t('pages.accounts.accounts')} pages={[{ name: `${t('pages.dashboard.dashboard')}`, path: '/' }]} />

      {accounts.errors.length > 0 && <Alert status="error" variant="left-accent" marginBottom={8}>
        <AlertIcon />
        {accounts.errors?.map((error, index) => (
          <Text key={index}>{error?.msg}</Text>
        ))}
      </Alert>}

      <SimpleGrid columns={{ base: 2, md: 2, lg: 3 }} mb={8} spacing={6}>
        <Flex boxShadow={theme.shadow} bg="#d7b323" padding={6} alignItems="center" justifyContent="space-between">
          <Flex justifyContent="space-between">
            <Box color={theme.light}>
              <FiIcons.FiDollarSign size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.light}
            >
              <span style={{ color: theme.light }}>{accounts.data?.pendingBalance || '-'}</span>
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.light}>
              ارصدة معلقه
            </Text>
          </Box>
        </Flex>
        <Flex boxShadow={theme.shadow} bg="#009ef7" padding={6} alignItems="center" justifyContent="space-between">
          <Flex justifyContent="space-between">
            <Box color={theme.light}>
              <FiIcons.FiDollarSign size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.light}
            >
              <span style={{ color: theme.light }}>{accounts.data?.preparingBalance || '-'}</span>
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.light}>
              ارصدة جار التحضير
            </Text>
          </Box>
        </Flex>
        <Flex boxShadow={theme.shadow} bg="#f1416c" padding={6} alignItems="center" justifyContent="space-between">
          <Flex justifyContent="space-between">
            <Box color={theme.light}>
              <FiIcons.FiDollarSign size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.light}
            >
              <span style={{ color: theme.light }}>{accounts.data?.shippedBalance || '-'}</span>
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.light}>
              ارصدة تم الشحن
            </Text>
          </Box>
        </Flex>
        <Flex boxShadow={theme.shadow} bg={theme.primary} padding={6} alignItems="center" justifyContent="space-between">
          <Flex justifyContent="space-between">
            <Box color={theme.light}>
              <FiIcons.FiDollarSign size={50} />
            </Box>
          </Flex>
          <Box>
            <Text
              fontWeight="bold" fontSize={30} mt={4} color={theme.light}
            >
              <span style={{ color: theme.light }}>{accounts.data?.availableBalance || '-'}</span>
            </Text>
            <Text
              fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.light}>
              ارصدة متاحه
            </Text>
          </Box>
        </Flex>
      </SimpleGrid>

      <Filter
        handleFilter={(values) => setFilter(JSON.stringify({ ...values, ...defaultFilter }))}
        handleClearFilter={() => setFilter(JSON.stringify(defaultFilter))}
        disablesBtns={accounts.isLoading}
      />

      {accounts.data?.itemsCount > 0 ? (
        <MarktersAccountsTable
          data={accounts.data.data}
          page={page}
        />
      ) : (
        <Flex textAlign="center" bg={theme.light} boxShadow={theme.shadow} height={200} alignItems="center"
          justifyContent="center" borderRadius={16}>
          <Text fontSize={18} textTransform="capitalize" color="gray.300" fontWeight="bold">
            {t('pages.accounts.no_accounts')}
          </Text>
        </Flex>
      )}

      <Flex justifyContent="flex-end">
        <Pagination
          page={page}
          itemsCount={accounts.data?.itemsCount ?? 0}
          onChange={(page) => setPage(page)}
        />
      </Flex>
    </MarktersAccountsWrapper>
  )
}

export default MarktersAccounts