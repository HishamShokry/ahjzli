import React from 'react';
import { useTranslation } from 'react-i18next';

import Table from '../../shared/table/Table';

const MarktersAccountsTable = ({ data, page }) => {
  const { t } = useTranslation();
  return (
    <Table>
      <thead>
        <tr>
          <th>#</th>
          <th>{t('pages.accounts.marketer')}</th>
          <th>الكود</th>
          <th>رقم الهاتف</th>
          <th>{t('pages.accounts.pending')}</th>
          <th>{t('pages.accounts.preparing')}</th>
          <th>{t('pages.accounts.shipped')}</th>
          <th>{t('pages.accounts.available')}</th>
        </tr>
      </thead>
      <tbody>
        {data.map((el, index) => (
          <tr key={el._id}>
            <td>{((page - 1) * 10) + (index + 1)}</td>
            <td>{el.marketer?.name}</td>
            <td>{el.marketer?.code}</td>
            <td>{el.marketer?.phone}</td>
            <td>{el.pending}</td>
            <td>{el.preparing}</td>
            <td>{el.shipped}</td>
            <td>{el.available}</td>
          </tr>
        ))}
      </tbody>
    </Table>
  )
}

export default MarktersAccountsTable