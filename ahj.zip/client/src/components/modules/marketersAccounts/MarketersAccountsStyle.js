import styled from 'styled-components';

export const MarktersAccountsWrapper = styled.div`

`;