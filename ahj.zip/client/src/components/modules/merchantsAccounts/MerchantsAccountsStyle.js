import styled from 'styled-components';

export const MerchantsAccountsWrapper = styled.div`

`;