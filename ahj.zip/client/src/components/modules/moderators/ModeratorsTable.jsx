import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@chakra-ui/react';
import * as FiIcons from 'react-icons/fi';

import Table from '../../shared/table/Table';

const ModeratorsTable = ({ data, page, handleUpdate }) => {
  const { t } = useTranslation();
  return (
    <Table>
      <thead>
        <tr>
          <th>#</th>
          <th>{t('pages.moderators.name')}</th>
          <th>{t('pages.moderators.email')}</th>
          <th>{t('pages.moderators.phone')}</th>
          <th>{t('pages.moderators.code')}</th>
          <th>نوع الحساب</th>
          <th>{t('pages.moderators.is_active')}</th>
          <th>{t('general.action')}</th>
        </tr>
      </thead>
      <tbody>
        {data.map((el, index) => (
          <tr key={el._id}>
            <td>{((page - 1) * 10) + (index + 1)}</td>
            <td>{el.name}</td>
            <td>{el.email}</td>
            <td>{el.phone}</td>
            <td>{el.code}</td>
            <td>{el.role}</td>
            <td>{el.is_active ? t('general.yes') : t('general.no')}</td>
            <td>
              <Button
                bg="transparent" color="green" size="xs"
                onClick={() => handleUpdate(el)}
              >
                <FiIcons.FiEdit size={20} />
              </Button>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  )
}

export default ModeratorsTable