import styled from 'styled-components';

export const ModeratorsWrapper = styled.div`

`;