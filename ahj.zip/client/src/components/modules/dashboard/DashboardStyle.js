import styled from 'styled-components';

export const DashboardWrapper = styled.div`
  
`;