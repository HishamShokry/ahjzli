import { useState, useEffect } from 'react';
import { useTranslation } from "react-i18next";
import { useSelector, useDispatch } from 'react-redux';
import { SimpleGrid, Box, Text, Flex, Table, Thead, Tr, Th, Tbody, Td, } from '@chakra-ui/react';

import Filter from "./actions/Filter";

import * as FiIcons from 'react-icons/fi';

import { getStatistics } from "../../../store/dashboard/statisticsSlice";

import theme from "../../global/theme";

import { DashboardWrapper } from "./DashboardStyle";


const Dashboard = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const statistics = useSelector(state => state.statistics);
  const auth = useSelector(state => state.auth);

  const [filter, setFilter] = useState({});

  useEffect(() => {
    dispatch(getStatistics({ filter: JSON.stringify(filter) }));
  }, [dispatch, filter]);

  return (
    <DashboardWrapper>
      <Flex paddingBlock={8} justifyContent="space-between" alignItems="center">
        <Text
          fontWeight="bold" textTransform="capitalize"
          fontSize={16} color={theme.dark}
        >
          التقارير العامة
        </Text>
        <Filter
          isLoading={statistics.isLoading}
          handleFilter={(values) => setFilter(values)}
          handleClearFilter={() => setFilter({})}
        />
      </Flex>

      {((auth.user.role === "admin" && auth.user?.rule?.permissions.includes("manage_dashboard")) || auth.user.role === "moderator" || auth.user.role === "marketer" || auth.user.role === "merchant") && (
        <SimpleGrid columns={{ sm: 1, lg: 3, xl: 4 }} spacing={6}>
          <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
            <Flex justifyContent="space-between">
              <Box color="#F78B00">
                <FiIcons.FiShoppingBag size={40} />
              </Box>
            </Flex>
            <Box>
              <Text
                fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
              >
                {statistics.data?.ordersOfToday}
              </Text>
              <Text
                fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                طلبات اليوم
              </Text>
            </Box>
          </Flex>

          <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
            <Flex justifyContent="space-between">
              <Box color="#F44336">
                <FiIcons.FiShoppingBag size={50} />
              </Box>
            </Flex>
            <Box>
              <Text
                fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
              >
                {statistics.data?.ordersOfWeek}
              </Text>
              <Text
                fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                طلبات هذا الاسبوع
              </Text>
            </Box>
          </Flex>

          <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
            <Flex justifyContent="space-between">
              <Box color="#F44336">
                <FiIcons.FiShoppingBag size={50} />
              </Box>
            </Flex>
            <Box>
              <Text
                fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
              >
                {statistics.data?.ordersOfMonth}
              </Text>
              <Text
                fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                طلبات هذا الشهر
              </Text>
            </Box>
          </Flex>

          <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
            <Flex justifyContent="space-between">
              <Box color="#F44336">
                <FiIcons.FiShoppingBag size={50} />
              </Box>
            </Flex>
            <Box>
              <Text
                fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
              >
                {statistics.data?.totalOrders}
              </Text>
              <Text
                fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                اجمالي الطلبات
              </Text>
            </Box>
          </Flex>

          {auth.user.role !== "moderator" && (
            <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color={theme.success}>
                  <FiIcons.FiDollarSign size={50} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
                >
                  {(statistics.data?.totalDoneRequests && statistics.data?.totalDoneRequests[0]?.amount) ?? 0}
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                  ارباح تم سحبها
                </Text>
              </Box>
            </Flex>
          )}

          <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
            <Flex justifyContent="space-between">
              <Box color={theme.success}>
                <FiIcons.FiDollarSign size={50} />
              </Box>
            </Flex>
            <Box>
              <Text
                fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
              >
                {(statistics.data?.totalSales && statistics.data?.totalSales[0]?.total) ?? 0}
              </Text>
              <Text
                fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                اجمالي المبيعات
              </Text>
            </Box>
          </Flex>

          {auth.user.role !== "moderator" && (
            <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color={theme.success}>
                  <FiIcons.FiDollarSign size={50} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
                >
                  {(statistics.data?.totalIncome && statistics.data?.totalIncome[0]?.commission) ?? 0}
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                  اجمالي الارباح
                </Text>
              </Box>
            </Flex>
          )}

          <Flex boxShadow={theme.shadow} bg={theme.success} padding={6} alignItems="center" justifyContent="space-between">
            <Flex justifyContent="space-between">
              <Box color={theme.light}>
                <FiIcons.FiPercent size={50} />
              </Box>
            </Flex>
            <Box>
              <Text
                fontWeight="bold" fontSize={30} mt={4} color={theme.light}
              >
                <span style={{ color: theme.light }}>{statistics.data?.percent?.toFixed(2) ?? '-'}</span>
              </Text>
              <Text
                fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.light}>
                نسبة التسليم
              </Text>
            </Box>
          </Flex>

          {(auth.user.role === "admin" || auth.user.role === "marketer") && (
            <Flex boxShadow={theme.shadow} bg={theme.success} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color={theme.light}>
                  <FiIcons.FiPercent size={50} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.light}
                >
                  <span style={{ color: theme.light }}>{statistics.data?.callCenterQuality?.toFixed(2) ?? '-'}</span>
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.light}>
                  جودة العملاء ونسبة التأكيد
                </Text>
              </Box>
            </Flex>
          )}

        </SimpleGrid>
      )}

      {(auth.user?.role === "admin" && auth.user?.rule?.permissions.includes("manage_dashboard")) && (
        <Box>
          <Flex paddingBlock={8} justifyContent="space-between" alignItems="center">
            <Text
              fontWeight="bold" textTransform="capitalize"
              fontSize={16} color={theme.dark}
            >
              {t('general.details')}
            </Text>
          </Flex>

          <SimpleGrid columns={{ sm: 1, lg: 3, xl: 4 }} spacing={6}>
            <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color="#F78B00">
                  <FiIcons.FiShoppingCart size={40} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
                >
                  {statistics.data?.totalProducts}
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                  المنتجات
                </Text>
              </Box>
            </Flex>

            <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color="#F78B00">
                  <FiIcons.FiShoppingCart size={40} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
                >
                  {statistics.data?.activeProducts}
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                  المنتجات النشطه
                </Text>
              </Box>
            </Flex>

            <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color="#F78B00">
                  <FiIcons.FiShoppingCart size={40} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
                >
                  {statistics.data?.disActiveProducts}
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                  المنتجات الغير نشطة
                </Text>
              </Box>
            </Flex>

            <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color="#F78B00">
                  <FiIcons.FiUsers size={40} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
                >
                  {statistics.data?.users}
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                  المستخدمين
                </Text>
              </Box>
            </Flex>

            <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color="#F78B00">
                  <FiIcons.FiUsers size={40} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
                >
                  {statistics.data?.merchants}
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                  التجار
                </Text>
              </Box>
            </Flex>

            <Flex boxShadow={theme.shadow} bg={theme.light} padding={6} alignItems="center" justifyContent="space-between">
              <Flex justifyContent="space-between">
                <Box color="#F78B00">
                  <FiIcons.FiUsers size={40} />
                </Box>
              </Flex>
              <Box>
                <Text
                  fontWeight="bold" fontSize={30} mt={4} color={theme.dark}
                >
                  {statistics.data?.marketers}
                </Text>
                <Text
                  fontWeight="bold" fontSize={16} textTransform="capitalize" color={theme.dark}>
                  المسوقين
                </Text>
              </Box>
            </Flex>

          </SimpleGrid>

          <SimpleGrid columns={{ sm: 1, lg: 2, xl: 3 }} spacing={6} mt={8}>
            <Box>
              <Text
                fontWeight="bold" textTransform="capitalize"
                fontSize={16} color={theme.dark} mb={4}
              >
                المسوقين الآكثر نشاطا
              </Text>
              <Table bg="white">
                <Thead>
                  <Tr>
                    <Th>#</Th>
                    <Th>اسم المسوق</Th>
                    <Th>عدد الاوردرات</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {statistics.data?.mostMarketers?.map((el, index) => (
                    <Tr key={index}>
                      <Td>{index + 1}</Td>
                      <Td>{el.user?.name}</Td>
                      <Td>{el.orderCount}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Box>

            <Box>
              <Text
                fontWeight="bold" textTransform="capitalize"
                fontSize={16} color={theme.dark} mb={4}
              >
                المسوقين الاكثر نشاطا هذا الاسبوع
              </Text>
              <Table bg="white">
                <Thead>
                  <Tr>
                    <Th>#</Th>
                    <Th>اسم المسوق</Th>
                    <Th>عدد الاوردرات</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {statistics.data?.marketersOfWeek?.map((el, index) => (
                    <Tr key={index}>
                      <Td>{index + 1}</Td>
                      <Td>{el.user?.name}</Td>
                      <Td>{el.orderCount}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Box>

            <Box>
              <Text
                fontWeight="bold" textTransform="capitalize"
                fontSize={16} color={theme.dark} mb={4}
              >
                المسوقين الاكثر نشاطا هذا الشهر
              </Text>
              <Table bg="white">
                <Thead>
                  <Tr>
                    <Th>#</Th>
                    <Th>اسم المسوق</Th>
                    <Th>عدد الاوردرات</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {statistics.data?.marketersOfMonth?.map((el, index) => (
                    <Tr key={index}>
                      <Td>{index + 1}</Td>
                      <Td>{el.user?.name}</Td>
                      <Td>{el.orderCount}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Box>
          </SimpleGrid>
        </Box>
      )}
    </DashboardWrapper>
  )
}

export default Dashboard