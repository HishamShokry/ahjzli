import styled from 'styled-components';

export const AvailableWrapper = styled.div`

`;