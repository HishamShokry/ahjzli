import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';

import { Flex, Text, Alert, AlertIcon, Button, Spinner } from '@chakra-ui/react';

import InputSearch from "../../../shared/inputSearch/InputSearch";
import Pagination from '../../../shared/pagination/Pagination';
import Breadcrumbs from '../../../shared/breadcrumbs/Breadcrumbs';
import AvailableList from './AvailableList';

import { getProducts } from '../../../../store/products/productsSlice';
import { getCategories } from "../../../../store/categories/categoriesSlice";

import { AvailableWrapper } from './AvailableStyle';

import theme from '../../../global/theme';

const Available = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const products = useSelector(state => state.products);
  const categories = useSelector(state => state.categories);

  const [page, setPage] = useState(1);
  const [query, setQuery] = useState("");
  const defaultFilter = { is_active: true };
  const [filter, setFilter] = useState(JSON.stringify(defaultFilter));

  useEffect(() => {
    dispatch(getProducts({ page, query, filter }));
  }, [dispatch, page, query, filter]);

  useEffect(() => {
    dispatch(getCategories({ page: 1, size: 200, query: "" }));
  }, [dispatch]);


  return (
    <AvailableWrapper>
      <Breadcrumbs currentPage={t('pages.products.products')} pages={[{ name: `${t('pages.dashboard.dashboard')}`, path: '/' }]} />

      {products.errors.length > 0 && <Alert status="error" variant="left-accent" marginBottom={8}>
        <AlertIcon />
        {products.errors?.map((error, index) => (
          <Text key={index}>{error?.msg}</Text>
        ))}
      </Alert>}

      <Flex marginBottom={8} justifyContent="flex-end">
        <InputSearch
          isLoading={products.isLoading}
          handleSearch={(query) => setQuery(query)}
        />
      </Flex>

      <Flex alignItems="center" mb={8} flexWrap="wrap">
        <Button
          bg={!filter.category ? theme.primary : "none"}
          border={`1px solid ${!filter.category ? theme.primary : "#eee"}`}
          color={!filter.category ? theme.light : theme.dark}
          _hover={{ bg: theme.primary, color: theme.light }}
          me={3} marginBlock={3}
          onClick={() => {
            const currentFilter = JSON.parse(filter);
            delete currentFilter.category;
            setFilter(JSON.stringify(currentFilter))
          }}
        >
          {t("pages.products.products")}
        </Button>

        {categories.isLoading && <Spinner />}

        {categories?.data?.data?.map(cat => (
          <Button key={cat._id}
            bg={filter.category === cat._id ? theme.primary : "none"}
            border={`1px solid ${filter.category === cat._id ? theme.primary : "#eee"}`}
            color={filter.category === cat._id ? theme.light : theme.dark}
            _hover={{ bg: theme.primary, color: theme.light }}
            me={3} marginBlock={3}
            onClick={() => {
              const currentFilter = JSON.parse(filter);
              currentFilter.category = cat._id;
              setFilter(JSON.stringify(currentFilter));
            }}
          >
            {cat.name}
          </Button>
        ))}
      </Flex>


      {products.data?.itemsCount > 0 ? (
        <AvailableList
          data={products.data.data}
          page={page}
        />
      ) : (
        <Flex textAlign="center" bg={theme.light} boxShadow={theme.shadow} height={200} alignItems="center"
          justifyContent="center" borderRadius={16}>
          <Text fontSize={18} textTransform="capitalize" color="gray.300" fontWeight="bold">
            {t('pages.products.no_products')}
          </Text>
        </Flex>
      )}

      <Flex justifyContent="flex-end">
        <Pagination
          page={page}
          itemsCount={products.data?.itemsCount ?? 0}
          onChange={(page) => setPage(page)}
        />
      </Flex>
    </AvailableWrapper>
  )
}

export default Available