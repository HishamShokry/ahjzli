import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { SimpleGrid, Box, Image, Heading, Text, Flex, Link as ChakraLink } from '@chakra-ui/react';


import theme from '../../../global/theme';

const AvailableList = ({ data }) => {
  const { t } = useTranslation();

  const getTotalQuantity = (item) => {
    let total = 0;
    for (let i = 0; i < item.properties.length; i++) {
      total += item.properties[i]?.value;
    }
    return total
  }

  return (
    <SimpleGrid bg={theme.light} boxShadow={theme.shadow} columns={{ sm: 1, md: 2, lg: 3 }} spacing={6} p={4} borderRadius={18}>
      {data.map(el => (
        <Box key={el._id} border={`1px solid ${theme.border}`} borderRadius={18} p={3}>
          <Flex as={Link} to={`/available_products/${el._id}`}
            h="280px" borderRadius={18} bg="#ededed" boxShadow={theme.shadow} justifyContent="center" alignItems="center"
          >
            <Image objectFit="contain" maxH="280px" src={`/products/${el.image}`} />
          </Flex>
          <Heading
            as="h5" color={theme.dark} mt={3} mb={4}
            fontSize={18} textAlign="center"
          >
            {el.name}
          </Heading>

          <Flex
            color={theme.dark} alignItems="center" mt={2}
            fontWeight="500" fontSize="16px"
          >
            <Text ms={1} me={4} fontSize="16px">{t('pages.products.barcode')}: </Text>
            <Text>{el.barcode}</Text>
          </Flex>

          <Flex
            color={theme.dark} alignItems="center" mt={2}
            fontWeight="500" fontSize="16px"
          >
            <Text ms={1} me={4} fontSize="16px">الكمية: </Text>
            <Text>{getTotalQuantity(el)}</Text>
          </Flex>

          <Flex
            color={theme.dark} alignItems="center" mt={2}
            fontWeight="500" fontSize="16px"
          >
            <Text ms={1} me={4} fontSize="16px">{t('pages.products.sale_price')}: </Text>
            <Text>{el.sale_price}</Text>
          </Flex>

          <Flex
            color={theme.dark} alignItems="center" mt={2}
            fontWeight="500" fontSize="16px"
          >
            <Flex fontWeight="bold" color={theme.error}>
              <Box display="inline-block" me={3} color={theme.blue}>ملاحظة: </Box>
              {el?.note}
            </Flex>
          </Flex>

          <Flex>
            <ChakraLink as={Link} to={`/available_products/${el._id}`} bg="#333054"
              display="block" w="100%" paddingBlock={2} borderRadius="5px" textAlign="center" color={theme.light}
              mt={6} textTransform="capitalize">
              {t('general.details')}
            </ChakraLink>
          </Flex>

          <Flex>
            <ChakraLink href={el.media_url} bg={theme.blue}
              display="block" w="100%" paddingBlock={2} borderRadius="5px" textAlign="center" color={theme.light}
              mt={6} textTransform="capitalize">
              {t('pages.products.media_url')}
            </ChakraLink>
          </Flex>
        </Box>
      ))}
    </SimpleGrid>
  )
}

export default AvailableList