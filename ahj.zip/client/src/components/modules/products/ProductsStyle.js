import styled from 'styled-components';

export const ProductsWrapper = styled.div`

`;