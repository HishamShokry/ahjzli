import React from 'react'

const OrdersTab = () => {
  return (
    <div>OrdersTab</div>
  )
}

export default OrdersTab