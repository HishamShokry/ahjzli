import styled from 'styled-components';

export const ProfileWrapper = styled.div`
  .chakra-link {
    &.active {
      color: ${({ theme }) => theme.secColor};
    }
  }
`;