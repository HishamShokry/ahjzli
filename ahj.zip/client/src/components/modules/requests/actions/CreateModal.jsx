import React from 'react';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { useSelector, useDispatch } from 'react-redux';

import {
  Modal, ModalOverlay,
  ModalContent, ModalHeader,
  ModalFooter, ModalBody,
  Button, FormControl,
  FormLabel, Input,
  Textarea, SimpleGrid,
  Flex, Text,
  Alert, AlertIcon
} from '@chakra-ui/react';

import * as FiIcons from 'react-icons/fi';

import { createRequest } from '../../../../store/requests/requestsSlice';

import theme from '../../../global/theme';

const CreateModal = ({ onClose }) => {
  const { t } = useTranslation();
  const requests = useSelector(state => state.requests);
  const dispatch = useDispatch();

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    defaultValues: {}
  });

  return (
    <Modal isOpen={true} onClose={onClose} size="xl">
      <ModalOverlay />
      <ModalContent borderRadius={20} paddingBlock={4} bg={theme.dark}>
        <form onSubmit={handleSubmit(values => {
          dispatch(createRequest(values)).unwrap().then(_ => {
            onClose();
          });
        })}>
          <ModalHeader textAlign="center" color="orange" textTransform="uppercase" fontSize={22}>
            {t('pages.requests.create_request')}
          </ModalHeader>
          <ModalBody>

            {requests.errors.length > 0 && <Alert status="error" variant="left-accent" marginBottom={8}>
              <AlertIcon />
              {requests.errors?.map((error, index) => (
                <Text key={index}>{error?.msg}</Text>
              ))}
            </Alert>}

            <SimpleGrid columns={{ sm: 1 }} spacing={6}>
              <FormControl>
                <FormLabel fontWeight="bold" textTransform="capitalize" color="white">
                  {t('pages.requests.phone')}
                </FormLabel>
                <Input type="tel" bg={theme.bg} color={theme.dark} border="none" borderRadius={4}
                  placeholder={t('pages.requests.phone')} _placeholder={{ textTransform: 'capitalize' }}
                  {...register("phone", {
                    required: `${t('validation.required')}`,
                    minLength: {
                      value: 11,
                      message: `${t('validation.min_length')} 11`
                    },
                    maxLength: {
                      value: 11,
                      message: `${t('validation.max_length')} 11`
                    }
                  })}
                />
                {errors.phone?.message &&
                  <Text color="red.600" marginTop={2}>{errors.phone.message}</Text>}
              </FormControl>

              <FormControl>
                <FormLabel fontWeight="bold" textTransform="capitalize" color="white">
                  {t('pages.requests.payment_method')}
                </FormLabel>
                <Input type="text" bg={theme.bg} color={theme.dark} border="none" borderRadius={4}
                  placeholder={t('pages.requests.payment_method')} _placeholder={{ textTransform: 'capitalize' }}
                  {...register("payment_method", {
                    required: `${t('validation.required')}`
                  })}
                />
                {errors.payment_method?.message &&
                  <Text color="red.600" marginTop={2}>{errors.payment_method.message}</Text>}
              </FormControl>

              <FormControl>
                <FormLabel fontWeight="bold" textTransform="capitalize" color="white">
                  {t('pages.requests.amount')}
                </FormLabel>
                <Input type="number" bg={theme.bg} color={theme.dark} border="none" borderRadius={4}
                  placeholder={t('pages.requests.amount')} _placeholder={{ textTransform: 'capitalize' }}
                  {...register("amount", {
                    required: `${t('validation.required')}`,
                    min: {
                      value: 1,
                      message: `${t('validation.min_length')} 1`
                    }
                  })}
                />
                {errors.amount?.message &&
                  <Text color="red.600" marginTop={2}>{errors.amount.message}</Text>}
              </FormControl>

              <FormControl>
                <FormLabel fontWeight="bold" textTransform="capitalize" color="white">
                  {t('pages.requests.note')}
                </FormLabel>
                <Textarea bg={theme.bg} color={theme.dark} border="none" borderRadius={4}
                  placeholder={t('pages.requests.note')} _placeholder={{ textTransform: 'capitalize' }}
                  {...register("note", {
                    maxLength: {
                      value: 150,
                      message: `${t('validation.max_length')} 150`
                    }
                  })}
                />
                {errors.note?.message &&
                  <Text color="red.600" marginTop={2}>{errors.note.message}</Text>}
              </FormControl>
            </SimpleGrid>
          </ModalBody>
          <ModalFooter>
            <Flex justifyContent="flex-end">
              <Button
                type="submit"
                rightIcon={<FiIcons.FiSave />}
                color="white" bg="green" paddingInline={4}
                paddingBlock={2} height="auto" textTransform="capitalize"
                isLoading={requests.isLoading}
                _hover={{ background: 'green' }}
              >
                {t('general.save')}
              </Button>
              <Button
                type="button"
                rightIcon={<FiIcons.FiMinimize2 />}
                color="white" bg="red.600" paddingInline={4}
                paddingBlock={2} height="auto" textTransform="capitalize"
                marginInlineStart={4}
                isLoading={requests.isLoading}
                _hover={{ background: 'red.600' }}
                onClick={onClose}
              >
                {t('general.close')}
              </Button>
            </Flex>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  )
}

export default CreateModal