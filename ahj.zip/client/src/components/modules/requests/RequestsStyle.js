import styled from 'styled-components';

export const RequestsWrapper = styled.div`

`;