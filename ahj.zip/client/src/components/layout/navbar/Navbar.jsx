import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

import {
  Button, Flex,
  Menu, MenuButton,
  MenuList, Text,
  Avatar, Box, Divider
} from '@chakra-ui/react';

import * as FiIcons from 'react-icons/fi';

import { toggleSidebar } from '../../../store/sidebar/sidebarSlice';
import { getNotifications } from "../../../store/notifications/notificationsSlice";
import { logout } from '../../../store/auth/authSlice';

import { NavbarWrapper } from './NavbarStyle';

import theme from '../../global/theme';


const Navbar = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const auth = useSelector(state => state.auth);
  const cart = useSelector(state => state.cart);
  const sidebar = useSelector(state => state.sidebar);
  const notifications = useSelector(state => state.notifications);

  const navigate = useNavigate();


  useEffect(() => {
    dispatch(getNotifications({ page: 1, query: "" }));
  }, [dispatch]);

  return (
    <NavbarWrapper className={`${sidebar.isNotOpened ? 'active' : ''}`}>
      <Flex alignItems="center" justifyContent="space-between">

        {/* start side */}
        <Button
          p={0} bg="none"
          width="auto" color={theme.dark}
          _hover={{ bg: "none" }} _focus={{ outline: "none" }}
          marginInlineEnd={4} onClick={() => dispatch(toggleSidebar())}
        >
          <FiIcons.FiAlignRight size={25} />
        </Button>

        {/* end side */}
        <Flex alignItems="center">
          <Menu>
            <MenuButton
              as={Button} bg={theme.bg} color={theme.dark} onClick={() => navigate('/cart')}
              _hover={{ bg: "none" }} _focus={{ outline: "none" }} me={3}
            >
              <Flex>
                <FiIcons.FiShoppingCart size={20} />
                <Box
                  w="20px" h="20px" borderRadius="50%"
                  bg={theme.error} color={theme.light}
                >
                  {cart.items.length}
                </Box>
              </Flex>
            </MenuButton>
          </Menu>

          <Menu>
            <MenuButton
              as={Button} bg={theme.bg} color={theme.dark} onClick={() => navigate('/notifications')}
              _hover={{ bg: "none" }} _focus={{ outline: "none" }}
            >
              <Flex>
                <FiIcons.FiBell size={20} />
                <Box
                  w="20px" h="20px" borderRadius="50%"
                  bg={theme.error} color={theme.light}
                >
                  {notifications.data?.isNotRead}
                </Box>
              </Flex>
            </MenuButton>
          </Menu>

          <Menu>
            <MenuButton
              as={Button} bg="none" color={theme.dark}
              _hover={{ bg: "none" }} _focus={{ outline: "none" }}
            >
              <Flex alignItems="center">
                <Avatar name={auth.user?.name} size="sm" />
                <Text className="profile-text"
                  marginInline={3} textTransform="capitalize"
                  fontSize={14}
                >
                  {auth.user?.name && auth.user.name.slice(0, 10)}
                </Text>
                <FiIcons.FiChevronDown size={16} />
              </Flex>
            </MenuButton>
            <MenuList minW="180px">
              <Box p={4}>

                <Box>
                  <Text
                    color={theme.dark} textTransform="capitalize"
                  >
                    {auth.user?.name && auth.user.name.slice(0, 10)}
                  </Text>
                  <Text
                    color={theme.secColor}
                  >
                    {auth.user?.role}: <b>{auth.user?.code}</b>
                  </Text>
                </Box>
                <Divider marginBlock={2} />
                <Flex as={Link} to="/profile"
                  alignItems="center"
                  color={theme.dark} textTransform="capitalize"
                >
                  <FiIcons.FiUser />
                  <Text ms={2}>
                    {t('layout.navbar.profile')}
                  </Text>
                </Flex>
                <Divider marginBlock={2} />
                <Box>
                  <Text as={Button} bg="none" p={0} _hover={{ bg: 'none' }}
                    color={theme.dark} textTransform="capitalize"
                    onClick={() => dispatch(logout())}
                  >
                    {t('layout.navbar.logout')}
                  </Text>
                </Box>
              </Box>
            </MenuList>
          </Menu>

        </Flex>
      </Flex>
    </NavbarWrapper>
  )
}

export default Navbar