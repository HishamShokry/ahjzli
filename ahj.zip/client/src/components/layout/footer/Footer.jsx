import { FooterWrapper } from './FooterStyle';

const Footer = () => {
  return (
    <FooterWrapper>
      powered by dev <span>Muhammed Mashhour</span>
    </FooterWrapper>
  )
}

export default Footer