import { createGlobalStyle } from 'styled-components';

export default createGlobalStyle`
  html {
    font-size: 16px;
  }

  body {
    background: ${({ theme }) => theme.bg} !important;
    min-height: 100vh;
    @media print {
      padding: 2rem;
      table {
        padding-top: 2rem;
      }
    }
  }

  .chakra-input__right-element, .chakra-select__icon-wrapper {
    ${({ theme }) => theme.end}: .5rem !important;
    ${({ theme }) => theme.start}: auto !important;
  }

  .chakra-input__left-element {
    ${({ theme }) => theme.start}: .5rem !important;
    ${({ theme }) => theme.end}: auto !important;
  }

  ul, ol {
    list-style: none;
  }

  button {
    &:focus {
      outline: none !important;
      box-shadow: none !important;
    }
  }

  textarea {
    resize: none !important;
  }
`;