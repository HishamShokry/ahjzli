import styled from 'styled-components';

export const SearchWrapper = styled.div`
`;